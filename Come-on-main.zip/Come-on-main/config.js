const CONFIG = {
    introTitle: 'Hi!',
    introDesc: `Welcome to thật lòng`,
    btnIntro: 'hihi',
    title: 'Phải chăng Khôi đã đẹp trai ngay từ cái nhìn đầu tiên 😙',
    desc: 'Phải chăng bạn đã nhận ra ngay từ lúc thấy nụ cười ấy ',
    btnYes: 'Đúng dị <33',
    btnNo: 'Điên à :3',
    question:'Trên thế giới hơn 7 tỉ người mà sao Khôi lại đẹp zai thế nhỡ <3',
    btnReply: 'Gửi cho Khôi <3',
    reply: 'Yêu thì yêu mà không yêu thì yêu <3333333',
    mess: 'Tui biết mà 🥰',
    messDesc: 'À, nhắn tin cái đi.',
    btnAccept: 'Okiiiii lun <3',
    messLink: 'https://www.messenger.com/t/100004900952229' //link mess của các bạn. VD: https://m.me/nam.nodemy
}
